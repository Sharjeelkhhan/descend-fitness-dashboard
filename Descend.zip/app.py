# app.py

import streamlit as st
import plotly.graph_objects as go
import os
from fitness_scoring import *

# logo width
LOGO_WIDTH = 170

# Helper to round numeric values to nearest integer for display
def round_int(value):
    try:
        return int(round(float(value)))
    except Exception:
        return value

st.set_page_config(page_title="DESCEND Fitness Dashboard", layout="wide")

# Custom CSS
st.markdown("""
    <style>
    .main {
        background-color: #2a2a2a;
        color: #ffffff;
    }
    h1, h2, h3, h4 {
        color: #ff8c00;
        font-family: 'Arial Black', sans-serif;
    }
    .stAlert {
        background-color: #1a1a1a;
    }
    .metric-card {
        background-color: #3a3a3a;
        padding: 15px;
        border-radius: 8px;
        border-left: 4px solid #ff8c00;
    }
    </style>
""", unsafe_allow_html=True)

# Header with logo 
col_logo, col_title = st.columns([1, 3])
with col_logo:
    logo_path = "logo.png"
    try:
        if os.path.exists(logo_path):
            st.image(logo_path, use_container_width=False, width=LOGO_WIDTH)
        else:
            st.markdown("### 🏔️ DESCEND")
            st.markdown("**GRAVITY CONDITIONING**")
    except Exception:
        st.markdown("### 🏔️ DESCEND")
        st.markdown("**GRAVITY CONDITIONING**")
with col_title:
    st.title("MTB Athlete Profile Dashboard")

st.markdown("---")

col1, col2 = st.columns([1, 2])

with col1:
    with st.form("fitness_form"):
        st.subheader("Test Data Input")
        
        # Athlete Profile
        st.markdown("#### Athlete Profile")
        test_date = st.date_input("Test Date")
        sex = st.selectbox("Sex", ["male", "female"])
        age = st.number_input("Age", min_value=10, max_value=100, value=38)
        bodyweight = st.number_input("Bodyweight (kg)", min_value=30.0, value=85.0)
        discipline = st.selectbox("Discipline", ["dh", "edr"])
        
        st.markdown("---")
        
        # Test Results 
        st.markdown("#### Strength Tests")
        trap_bar_3rm = st.number_input("TrapBar 3RM (kg)", min_value=0.0, value=180.0)
        split_squat_5rm = st.number_input("Split Squat 5RM (kg)", min_value=0.0, value=45.0)
        
        st.markdown("#### Endurance Tests")
        chin_ups = st.number_input("Chin Up (Reps)", min_value=0, value=12)
        goblet_reps = st.number_input("Goblet Squat (Reps)", min_value=0, value=30)
        
        st.markdown("#### Conditioning Tests")
        assault_bike = st.number_input("1 min Assault Bike (cal)", min_value=0.0, value=35.0)
        row_meters = st.number_input("3 min Row (Metres)", min_value=0.0, value=700.0)
        bike_12min = st.number_input("12 min bike (Watts)", min_value=0.0, value=200.0)
        bike_peak_watts = st.number_input("6s Bike (Peak Watts)", min_value=0.0, value=1500.0)
        
        st.markdown("#### Power Tests")
        med_ball_toss = st.number_input("Med Ball Toss (m)", min_value=0.0, value=7.0)
        
        # Benchmark standards
        with st.expander("⚙️ Advanced: Adjust Standards"):
            aerobic_std = st.number_input("Aerobic Standard", value=3000.0)
            rower_std = st.number_input("Rower Standard", value=800.0)
            airbike_std = st.number_input("Airbike Standard", value=50.0)
            sprint_std = st.number_input("Sprint Standard", value=1000.0)

        submitted = st.form_submit_button("🔄 Calculate Scores", use_container_width=True)

with col2:
    if submitted:
        # Calculate scores using the functions
        strength = compute_strength_score(trap_bar_3rm, bodyweight)
        endurance = compute_strength_endurance_score(split_squat_5rm, bodyweight)
        power = compute_power_score(200, med_ball_toss)  
        aerobic = compute_aerobic_score(bike_12min, aerobic_std)
        anaerobic = compute_anaerobic_score(row_meters, assault_bike, bike_peak_watts,
                                           rower_std, airbike_std, sprint_std)
        
        overall = compute_overall_score(strength, endurance, power, aerobic, anaerobic)
        program = recommend_program(overall, discipline)
        
        # Results header
        st.markdown("## MTB Athlete Profile – Strength | Endurance | Anaerobic | Aerobic | Power")
        
        # Horizontal bar chart matching the design
        categories = [
            "POWER SCORE",
            "AEROBIC SCORE", 
            "ANAEROBIC SCORE",
            "STRENGTH ENDURANCE SCORE",
            "ABSOLUTE STRENGTH SCORE"
        ]
        
        values = [power, aerobic, anaerobic, endurance, strength]
        
        fig = go.Figure()
        
        fig.add_trace(go.Bar(
            y=categories,
            x=values,
            orientation='h',
            marker=dict(
                color='#ff8c00',
                line=dict(color='#ff6600', width=1)
            ),
            text=[f"{round_int(v)}" for v in values],
            textposition='outside',
            textfont=dict(color='#ff8c00', size=14, family='Arial Black')
        ))
        
        fig.update_layout(
            plot_bgcolor='#2a2a2a',
            paper_bgcolor='#2a2a2a',
            font=dict(color='#ffffff', size=12, family='Arial'),
            xaxis=dict(
                range=[0, 12],
                showgrid=True,
                gridcolor='#404040',
                zeroline=True,
                zerolinecolor='#404040',
                tickvals=[0, 2, 4, 6, 8, 10],
                tickfont=dict(color='#999999')
            ),
            yaxis=dict(
                showgrid=False,
                tickfont=dict(color='#ffffff', size=11)
            ),
            height=350,
            margin=dict(l=200, r=50, t=20, b=40),
            showlegend=False
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Overall score and recommendation
        st.markdown("---")
        
        score_col, prog_col = st.columns(2)
        
        with score_col:
            st.markdown(f"### OVERALL SCORE: <span style='color: #ff8c00; font-size: 48px;'>{round_int(overall)}</span>", 
                       unsafe_allow_html=True)
        
        with prog_col:
            st.markdown(f"### RECOMMENDED PROGRAM: <span style='color: #ff8c00; font-size: 32px;'>{program}</span>", 
                       unsafe_allow_html=True)
        
        st.markdown("---")
        
        # Detailed score breakdown
        st.subheader("📊 Detailed Score Breakdown")
        
        metric_col1, metric_col2, metric_col3 = st.columns(3)
        
        with metric_col1:
            st.metric("Absolute Strength", f"{round_int(strength)}")
            st.metric("Strength Endurance", f"{round_int(endurance)}")
        
        with metric_col2:
            st.metric("Power", f"{round_int(power)}")
            st.metric("Aerobic", f"{round_int(aerobic)}")
        
        with metric_col3:
            st.metric("Anaerobic", f"{round_int(anaerobic)}")
            st.metric("Overall", f"{round_int(overall)}", 
                     delta=f"{round_int(overall - 10)} vs threshold")
        
        # Test performance summary
        st.markdown("---")
        st.subheader("📋 Test Performance Summary")
        
        summary_data = {
            "Test": ["Trap Bar 3RM", "Split Squat 5RM", "Chin Ups", "Goblet Squat", 
                "Assault Bike 1min", "Rower 3min", "12min Bike", "Peak Watts 6s", "Med Ball Toss"],
            "Result": [f"{round_int(trap_bar_3rm)}kg", f"{round_int(split_squat_5rm)}kg", f"{round_int(chin_ups)} reps", 
                  f"{round_int(goblet_reps)} reps", f"{round_int(assault_bike)} cal", f"{round_int(row_meters)}m", 
                  f"{round_int(bike_12min)}W", f"{round_int(bike_peak_watts)}W", f"{round_int(med_ball_toss)}m"],
            "Standard": [f"{round_int(2.5*bodyweight)}kg", f"{round_int(1.4*bodyweight)}kg", "-", "-", 
                f"{round_int(airbike_std)} cal", f"{round_int(rower_std)}m", f"{round_int(aerobic_std)}m", 
                f"{round_int(sprint_std)}W", "6m"]
        }
        
        import pandas as pd
        df = pd.DataFrame(summary_data)
        st.dataframe(df, use_container_width=True, hide_index=True)

    else:
        # Welcome screen
        st.markdown("## 👈 Enter Test Data to Generate Profile")
        st.markdown("---")
        st.markdown("""
        ### About the DESCEND Testing Protocol
        
        This comprehensive fitness assessment evaluates MTB athletes across **5 key performance domains**:
        
        #### 🏋️ Absolute Strength
        - Trap bar deadlift 3RM relative to bodyweight
        - Target: 2.5x bodyweight
        
        #### 💪 Strength Endurance  
        - Split squat 5RM capacity per leg
        - Target: 1.4x bodyweight
        
        #### ⚡ Power
        - Med ball toss distance
        - Combined explosive strength output
        
        #### 🫁 Aerobic Capacity
        - 12-minute sustained bike effort
        - Measures oxidative energy system
        
        #### 🔥 Anaerobic Capacity
        - Short-duration high-intensity tests
        - Assault bike, rower, peak power output
        
        ---
        
        **Scoring System:**
        - Each category: 0-10 points
        - Overall max: 50 points
        - Program threshold: 10 points
        
        **Program Recommendations:**
        - Score < 10: Foundation program (DH3/Enduro3)
        - Score ≥ 10: Performance program (DH2/Enduro2)
        """)
        
        st.info("💡 **Tip:** Fill in the form on the left and click 'Calculate Scores' to see your athlete profile.")