# fitness_scoring.py

def compute_strength_score(trap_bar_1rm, bodyweight):
    """
    Strength score (E4) based on trap bar deadlift vs bodyweight standard
    """
    trap_bar_standard = 2.5 * bodyweight
    score = (trap_bar_1rm / trap_bar_standard) * 10
    return round(min(score, 10), 2)


def compute_strength_endurance_score(split_squat, bodyweight):
    """
    Strength endurance score (G4) based on split squat vs bodyweight standard
    """
    split_squat_standard = 1.4 * bodyweight
    score = (split_squat / split_squat_standard) * 10
    return round(min(score, 10), 2)


def compute_power_score(broad_jump_cm, medball_toss):
    """
    Power score (J4) combines broad jump and med ball toss
    """
    broad_jump_standard = 200
    medball_standard = 6
    
    broad_jump_component = (broad_jump_cm / broad_jump_standard) * 0.5 * 10
    medball_component = (medball_toss / medball_standard) * 0.5 * 10
    
    score = broad_jump_component + medball_component
    return round(min(score, 10), 2)


def compute_aerobic_score(bike_12min_distance, aerobic_standard=3000):
    """
    Aerobic score (L4) based on 12-minute bike distance
    Default standard is 3000m, adjust as needed
    """
    score = (bike_12min_distance / aerobic_standard) * 10
    return round(min(score, 10), 2)


def compute_anaerobic_score(rower_3min, airbike_60s, sprint_6s, 
                            rower_standard=800, airbike_standard=50, sprint_standard=1000):
    """
    Anaerobic score (M4) averages three test outputs
    Defaults are example standards, adjust as needed
    """
    rower_component = rower_3min / rower_standard
    airbike_component = airbike_60s / airbike_standard
    sprint_component = sprint_6s / sprint_standard
    
    score = ((rower_component + airbike_component + sprint_component) / 3) * 10
    return round(min(score, 10), 2)


def compute_overall_score(strength, endurance, power, aerobic, anaerobic):
    """
    Overall score is sum of all category scores (max 50)
    """
    return round(strength + endurance + power + aerobic + anaerobic, 2)


def recommend_program(overall_score, discipline):
    """
    Program recommendation based on overall score and discipline
    Threshold changed from 15 to 10
    """
    if discipline.lower() == "dh":
        if overall_score < 10:
            return "DH3"
        else:
            return "DH2"
    
    elif discipline.lower() in ["enduro", "edr"]:
        if overall_score < 10:
            return "Enduro3"
        else:
            return "Enduro2"
    
    else:
        return "General Program"